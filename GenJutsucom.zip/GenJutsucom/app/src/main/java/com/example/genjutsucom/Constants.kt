package com.example.genjutsucom

object Constants {

    const val USER_NAME: String = "user_name"
    const val TOTAL_QUESTIONS: String = "total_questions"
    const val CORRECT_ANSWERS: String = "correct_answers"

    fun getQuestion(): ArrayList<Questions>{
        val questionsList = ArrayList<Questions>()

        val que1 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.a,
            "D",
            "N",
            "A",
            "X",
            3
        )

        val que2 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.b,
            "B",
            "T",
            "A",
            "W",
            1
        )

        val que3 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.c,
            "O",
            "C",
            "P",
            "F",
            2
        )

        val que4 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.d,
            "D",
            "G",
            "L",
            "R",
            1
        )

        val que5 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.e,
            "Q",
            "V",
            "S",
            "E",
            4
        )

        val que6 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.f,
            "F",
            "R",
            "S",
            "T",
            1
        )

        val que7 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.g,
            "U",
            "G",
            "N",
            "A",
            2
        )

        val que8 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.h,
            "Q",
            "X",
            "E",
            "H",
            4
        )

        val que9 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.i,
            "I",
            "L",
            "V",
            "E",
            1
        )

        val que10 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.l,
            "P",
            "L",
            "C",
            "M",
            2
        )

        val que11 = Questions(
            1,
            "Traduce esta letra",
            R.drawable.m,
            "K",
            "J",
            "M",
            "F",
            2
        )
        questionsList.add(que1)
        questionsList.add(que2)
        questionsList.add(que3)
        questionsList.add(que4)
        questionsList.add(que5)

        return questionsList
    }
}
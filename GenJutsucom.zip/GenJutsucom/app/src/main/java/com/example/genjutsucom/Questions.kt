package com.example.genjutsucom

data class Questions (

    val id: Int,
    val questions: String,
    val video: Int,
    val optionOne: String,
    val optionTwo: String,
    val optionThree: String,
    val optionFour: String,
    val correctAnswer: Int
    )